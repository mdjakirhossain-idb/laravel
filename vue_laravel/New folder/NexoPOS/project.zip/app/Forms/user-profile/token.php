<?php

return [
    'label' => __( 'API Token' ),
    'component' => 'nsToken',
];
