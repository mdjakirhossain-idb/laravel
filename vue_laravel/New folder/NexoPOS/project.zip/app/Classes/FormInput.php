<?php

namespace App\Classes;

class FormInput extends CrudInput
{
    // ... replicates the CrudInput
}
