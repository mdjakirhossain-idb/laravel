<?php

namespace App\Classes;

use TorMorten\Eventy\Facades\Eventy;

/**
 * @static nsDashboardMenus( $callback )
 */
class Hook extends Eventy
{
    const nsDashboardMenus = 'ns-dashboard-menus';
}
